# Security Policy

## Supported Versions

Its reccomended you always use the most up to date version. Version and build info can be found at the bottom right in the footer.
![shsgames github io_1](https://user-images.githubusercontent.com/31785395/158916730-cf7c2e1e-e815-450d-b526-e2b60f9388fa.png)

## Reporting a Vulnerability

If you suspect a vulnerability, please report it in the issues tab.
